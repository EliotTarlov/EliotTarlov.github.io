"""Registers the Family Booklet report with Gramps. The report itself is in viewer.py."""

register(
    REPORT,
    id="familybooklet",
    name=_("Family Booklet"),
    description=_(
        "Draws a couple's descendants as a booklet and as one wide sheet, "
        "in a web page you can print or save as a PDF."
    ),
    version="1.0.0",
    gramps_target_version="6.0",
    status=STABLE,
    fname="viewer.py",
    authors=["Eliot Tarlov"],
    authors_email=[""],
    category=CATEGORY_WEB,
    reportclass="FamilyBooklet",
    optionclass="FamilyBookletOptions",
    report_modes=[REPORT_MODE_GUI, REPORT_MODE_CLI],
)
