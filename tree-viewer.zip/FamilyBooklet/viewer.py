"""Family Booklet: a Gramps report that writes the family tree as one web page.

What it does: reads every person and family in the open tree, puts that data
into page.html, and saves the result as a single self-contained .html file.
The page draws the tree itself (see page.html) and prints it as a booklet or
as one wide sheet.

Gramps finds this report through viewer.gpr.py. It appears under
Reports > Web Pages > Family Booklet.
"""

import base64
import json
import os
import webbrowser
from pathlib import Path

from gramps.gen.const import USER_HOME
from gramps.gen.display.place import displayer as place_displayer
from gramps.gen.errors import ReportError
from gramps.gen.lib import Date, EventType, NameType, Person
from gramps.gen.plug.menu import BooleanOption, DestinationOption
from gramps.gen.plug.report import MenuReportOptions, Report

HERE = Path(__file__).parent
MONTHS = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
FONTS = [  # (CSS family, weight, file in fonts/)
    ("LM Dunhill", 400, "lm-dunhill.woff"),
    ("LM Quot", 400, "lm-quot.woff"),
    ("LM Quot", 700, "lm-quot-bold.woff"),
]


class FamilyBookletOptions(MenuReportOptions):
    """The two questions the report asks: where to save the page, and whether to open it."""

    def __init__(self, name, dbase):
        self.__db = dbase
        MenuReportOptions.__init__(self, name, dbase)

    def add_menu_options(self, menu):
        target = DestinationOption("Save the page as", os.path.join(USER_HOME, "Family Booklet.html"))
        target.set_directory_entry(False)
        target.set_extension(".html")
        target.set_help("The web page to write. An existing file with this name is replaced.")
        menu.add_option("Report Options", "target", target)

        show = BooleanOption("Open the page in my web browser when it is ready", True)
        show.set_help("Opens the finished page so you can look at it and print it.")
        menu.add_option("Report Options", "open", show)


class FamilyBooklet(Report):
    def __init__(self, database, options, user):
        Report.__init__(self, database, options, user)
        self.target = Path(options.menu.get_option_by_name("target").get_value()).expanduser()
        self.show = options.menu.get_option_by_name("open").get_value()

    def write_report(self):
        data = tree_data(self.database)
        if not data["F"]:
            raise ReportError("Nothing to draw", "This family tree has no families in it yet.")
        try:
            self.target.write_text(build_page(data), encoding="utf-8")
        except OSError as err:
            raise ReportError("Could not save the page", f"{self.target}: {err.strerror}")
        if self.show:
            webbrowser.open(self.target.resolve().as_uri())


# ── the page ──────────────────────────────────────────────────────────────

def build_page(data):
    """page.html with the fonts and the tree's data filled in."""
    fonts = "\n".join(
        f'@font-face {{ font-family: "{family}"; font-weight: {weight}; '
        f'src: url("data:font/woff;base64,{base64.b64encode((HERE / "fonts" / name).read_bytes()).decode()}") format("woff"); }}'
        for family, weight, name in FONTS
    )
    blob = json.dumps(data, ensure_ascii=False).replace("</", "<\\/")  # must not close its <script>
    page = (HERE / "page.html").read_text(encoding="utf-8")
    return page.replace("/*FONTS*/", fonts).replace("/*DATA*/", blob)


# ── the data ──────────────────────────────────────────────────────────────

def tree_data(db):
    """Everyone and every family in the tree, in the shape page.html reads.

    People and families are keyed by their Gramps IDs (I0001, F0001).
    Notes marked private in Gramps are left out.
    """
    people = {p.get_gramps_id(): person_data(db, p) for p in db.iter_people()}
    families = {f.get_gramps_id(): family_data(db, f) for f in db.iter_families()}
    return {"P": people, "F": families}


def person_data(db, person):
    name = person.get_primary_name()
    others = person.get_alternate_names()
    married = [n.get_surname() for n in others if n.get_type() == NameType.MARRIED]
    source = None
    for handle in person.get_citation_list():
        citation = db.get_citation_from_handle(handle)
        src = db.get_source_from_handle(citation.get_reference_handle())
        source = {"title": src.get_title(), "page": citation.get_page()}
        break
    return {
        "id": person.get_gramps_id(),
        "given": name.get_first_name(),
        "surn": name.get_surname(),
        "married": married[0] if married else "",
        "aka": [f"{n.get_first_name()} {n.get_surname()}".strip() for n in others if n.get_type() != NameType.MARRIED],
        "sex": {Person.MALE: "M", Person.FEMALE: "F"}.get(person.get_gender(), "U"),
        "birt": event_data(db, person.get_birth_ref()),
        "deat": event_data(db, person.get_death_ref()),
        "buri": first_event(db, person, EventType.BURIAL),
        "famc": family_id(db, person.get_main_parents_family_handle()),
        "fams": [family_id(db, h) for h in person.get_family_handle_list()],
        "notes": notes(db, person),
        "src": source,
    }


def family_data(db, family):
    children = [db.get_person_from_handle(ref.ref).get_gramps_id() for ref in family.get_child_ref_list()]
    return {
        "id": family.get_gramps_id(),
        "husb": person_id(db, family.get_father_handle()),
        "wife": person_id(db, family.get_mother_handle()),
        "chil": children,
        "marr": first_event(db, family, EventType.MARRIAGE),
        "div": first_event(db, family, EventType.DIVORCE) is not None,
        "notes": notes(db, family),
    }


def person_id(db, handle):
    return db.get_person_from_handle(handle).get_gramps_id() if handle else None


def family_id(db, handle):
    return db.get_family_from_handle(handle).get_gramps_id() if handle else None


def notes(db, obj):
    found = (db.get_note_from_handle(h) for h in obj.get_note_list())
    return [n.get() for n in found if not n.get_privacy()]


def first_event(db, obj, kind):
    """The first event of one kind (burial, marriage, divorce) on a person or family, or None."""
    for ref in obj.get_event_ref_list():
        if db.get_event_from_handle(ref.ref).get_type() == kind:
            return event_data(db, ref)
    return None


def event_data(db, ref):
    if ref is None:
        return None
    event = db.get_event_from_handle(ref.ref)
    return {"date": date_text(event.get_date_object()), "place": place_displayer.display_event(db, event)}


def date_text(date):
    """A Gramps date written the way the booklet shows it: '4 May 1906', 'about Aug 1918', '1869'."""
    if date is None or date.is_empty():
        return ""
    if date.get_modifier() == Date.MOD_TEXTONLY:
        return date.get_text().strip("()")

    def written(day, month, year):
        return " ".join(str(part) for part in (day or "", MONTHS[month], year or "") if part)

    text = written(date.get_day(), date.get_month(), date.get_year())
    if date.is_compound():
        stop = written(date.get_stop_day(), date.get_stop_month(), date.get_stop_year())
        text = f"{text} to {stop}"
    prefix = {Date.MOD_BEFORE: "before ", Date.MOD_AFTER: "after ", Date.MOD_ABOUT: "about ",
              Date.MOD_FROM: "from ", Date.MOD_TO: "until "}.get(date.get_modifier(), "")
    if date.get_quality() == Date.QUAL_CALCULATED and not prefix:
        prefix = "about "
    return prefix + text + ("?" if date.get_quality() == Date.QUAL_ESTIMATED else "")
