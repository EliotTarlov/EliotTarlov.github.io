# Family Booklet

A Gramps report that draws a couple's descendants as a web page. The page shows the tree two ways:

- **Booklet**: generations in columns, split over ordinary landscape pages.
- **One sheet**: the whole tree top-down on a single wide page.

Either one prints, or saves as a PDF, from the browser's print dialog.

## Install

Copy this `FamilyBooklet` folder into the Gramps plugins folder, then restart Gramps.

| System  | Plugins folder                                             |
|---------|------------------------------------------------------------|
| macOS   | `~/Library/Application Support/gramps/gramps60/plugins/`   |
| Linux   | `~/.local/share/gramps/gramps60/plugins/`                  |
| Windows | `%APPDATA%\gramps\gramps60\plugins\`                       |

Needs Gramps 6.0. Only the Linux path has been checked.

## Use

1. In Gramps, open the family tree.
2. Choose **Reports > Web Pages > Family Booklet**.
3. Pick where to save the page and press OK. The page opens in the web browser.
4. In the page, **Show one sheet** / **Show booklet** switches views. **Print** prints the view on screen.

To get a one-page PDF of the sheet: show the one sheet, press **Print one sheet**, and choose "Save as PDF" as the printer. Use Chrome or Edge; the page sets the paper size to fit the sheet, and other browsers may ignore that.

Run the report again after editing the tree. The page is a snapshot, not a live view.

## What the page contains

The saved `.html` file is self-contained: it holds the fonts and all the tree's data, including every note not marked private in Gramps. Notes show only when a person is clicked; they are not on the printed booklet or sheet. Send the PDF, not the `.html`, to keep the notes to yourself.

The tree starts from the couple with the most descendants.

## Files

| File            | Job                                                                 |
|-----------------|---------------------------------------------------------------------|
| `viewer.gpr.py` | Tells Gramps the report exists.                                     |
| `viewer.py`     | Reads people and families from Gramps and writes the page.          |
| `page.html`     | The page: layout, styles and drawing code. Settings are in `CONFIG`. |
| `fonts/`        | Latin Modern fonts, built into each saved page. GUST Font License.  |

From a terminal: `gramps -O "Tree name" -a report -p "name=familybooklet,target=/path/out.html,open=False"`.
